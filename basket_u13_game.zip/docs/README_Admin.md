# Guía Admin – Sprint 1
Panel Admin: Ctrl+Shift+A. Toggles de ayudas, telemetría, tutorial y pizarra. Exportar CSV de telemetría.
