# Basket U13 Game – v0.2.0 (Sprint 1)
Generado: 2025-09-03T11:20:20.248199
Novedades: nodos de decisión, tutorial, telemetría local (CSV), pizarra básica, recarga dura.

Cómo ejecutar (PowerShell):
  cd "C:\Users\lucia\Downloads\basket_u13_game"
  python -m http.server 8000
Abrir: http://localhost:8000/ (redirige a /public/index.html)

Verificar (200 OK):
  /public/js/lib/hardReload.js
  /public/js/lib/nodes.js
  /public/js/lib/tutorial.js
  /public/js/lib/telemetry.js
  /public/js/lib/playsUI.js
  /public/js/scenes/MainScene.js
